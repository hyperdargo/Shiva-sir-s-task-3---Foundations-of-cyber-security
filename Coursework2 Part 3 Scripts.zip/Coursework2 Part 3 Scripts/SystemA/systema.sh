#!/bin/bash

openssl genpkey -algorithm RSA -out private_keyA.pem
openssl rsa -pubout -in private_keyA.pem -out public_keyA.pem
echo "Confidential information from System A" > dataA.txt

