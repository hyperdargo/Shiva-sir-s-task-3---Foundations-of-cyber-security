#!/bin/bash

openssl dgst -sha256 -sign private_keyA.pem -out data_signatureA.sha256 dataA.txt
openssl enc -aes-256-cbc -salt -in dataA.txt -out encrypted_dataA.enc -pass pass:98170226

