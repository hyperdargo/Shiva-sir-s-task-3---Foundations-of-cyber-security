#!/bin/bash

openssl genpkey -algorithm RSA -out private_keyB.pem
openssl rsa -pubout -in private_keyB.pem -out public_keyB.pem
echo "Confidential information from System B" > dataB.txt
