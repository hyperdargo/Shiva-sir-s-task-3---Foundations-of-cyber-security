#!/bin/bash

openssl dgst -sha256 -sign private_keyB.pem -out data_signatureB.sha256 dataB.txt
openssl enc -aes-256-cbc -salt -in dataB.txt -out encrypted_dataB.enc -pass pass:051335