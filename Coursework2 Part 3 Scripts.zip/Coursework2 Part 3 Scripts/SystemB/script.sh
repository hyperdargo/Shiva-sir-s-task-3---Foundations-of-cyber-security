#!/bin/bash
openssl enc -d -aes-256-cbc -in encrypted_dataA.enc -out decrypted_dataA.txt -pass pass:98170226
